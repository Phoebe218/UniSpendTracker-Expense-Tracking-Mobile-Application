package com.example.campusspend;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.content.res.ColorStateList;
import android.graphics.Color;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private final List<AppNotification> notifications;
    private final OnNotificationDeleteListener deleteListener;

    public interface OnNotificationDeleteListener {
        void onDelete(int notificationId);
    }

    public NotificationAdapter(List<AppNotification> notifications, OnNotificationDeleteListener deleteListener) {
        this.notifications = notifications;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppNotification notification = notifications.get(position);
        holder.tvTitle.setText(notification.getTitle());
        holder.tvMsg.setText(notification.getMessage());
        holder.tvTime.setText(notification.getTimestamp());

        // Highlight unread notifications with a subtle surface tint
        if (notification.getIsRead() == 0) {
            holder.cardView.setCardBackgroundColor(ColorStateList.valueOf(Color.parseColor("#F1F5F9")));
        } else {
            holder.cardView.setCardBackgroundColor(ColorStateList.valueOf(Color.WHITE));
        }

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDelete(notification.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return notifications.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvMsg, tvTime;
        ImageButton btnDelete;
        MaterialCardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = (MaterialCardView) itemView;
            tvTitle = itemView.findViewById(R.id.tvNotifTitle);
            tvMsg = itemView.findViewById(R.id.tvNotifMsg);
            tvTime = itemView.findViewById(R.id.tvNotifTime);
            btnDelete = itemView.findViewById(R.id.btnDeleteNotif);
        }
    }
}

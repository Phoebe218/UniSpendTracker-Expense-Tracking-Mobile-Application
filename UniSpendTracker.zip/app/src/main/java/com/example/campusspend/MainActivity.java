package com.example.campusspend;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import android.view.View;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DatabaseHelper dbHelper;
    private TextView tvWelcome, tvTotalSpend, tvBudgetSubtitle, tvAnalysis, tvRecentTransactions;
    private TextView tvHighSpend, tvHighPct, tvMedSpend, tvMedPct, tvLowSpend, tvLowPct;
    private com.google.android.material.progressindicator.LinearProgressIndicator budgetProgressBar, progressHigh, progressMed, progressLow;
    private DrawerLayout drawerLayout;
    private BottomNavigationView bottomNavigationView;

    private int userId = -1;
    private String username = "Student";
    private int lastNotifiedPercent = 0;
    private static final String CHANNEL_ID = "CampusSpendAlerts";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);
        username = getIntent().getStringExtra("USERNAME");

        if (userId == -1) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        createNotificationChannel();
        requestNotificationPermission();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationIcon(R.drawable.ic_filled_menu);
        if (toolbar.getNavigationIcon() != null) {
            androidx.core.graphics.drawable.DrawableCompat.setTint(
                androidx.core.graphics.drawable.DrawableCompat.wrap(toolbar.getNavigationIcon()),
                getResources().getColor(R.color.on_primary, getTheme())
            );
        }

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Update nav header
        View headerView = navigationView.getHeaderView(0);
        TextView navUser = headerView.findViewById(R.id.nav_username);
        if (username != null) navUser.setText(username);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_stats_tab) {
                Intent intent = new Intent(this, InsightsActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            } else if (id == R.id.nav_vault_tab) {
                Intent intent = new Intent(this, SavingsVaultActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            }
            return true;
        });

        tvWelcome = findViewById(R.id.tvWelcome);
        tvTotalSpend = findViewById(R.id.tvTotalSpend);
        tvBudgetSubtitle = findViewById(R.id.tvBudgetSubtitle);
        tvAnalysis = findViewById(R.id.tvAnalysis);
        tvRecentTransactions = findViewById(R.id.tvRecentTransactions);
        budgetProgressBar = findViewById(R.id.budgetProgressBar);

        tvHighSpend = findViewById(R.id.tvHighSpend);
        tvHighPct = findViewById(R.id.tvHighPct);
        tvMedSpend = findViewById(R.id.tvMedSpend);
        tvMedPct = findViewById(R.id.tvMedPct);
        tvLowSpend = findViewById(R.id.tvLowSpend);
        tvLowPct = findViewById(R.id.tvLowPct);
        progressHigh = findViewById(R.id.progressHigh);
        progressMed = findViewById(R.id.progressMed);
        progressLow = findViewById(R.id.progressLow);

        Button btnViewAll = findViewById(R.id.btnViewAll);
        MaterialCardView cardHistory = findViewById(R.id.cardHistory);
        
        View.OnClickListener goToHistory = v -> {
            Intent intent = new Intent(this, SearchHistoryActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        };
        
        btnViewAll.setOnClickListener(goToHistory);
        cardHistory.setOnClickListener(goToHistory);

        ExtendedFloatingActionButton btnGoToAdd = findViewById(R.id.btnGoToAdd);

        tvWelcome.setText("Jambo, " + username + "!");

        btnGoToAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddExpenseActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
        checkBudgetExpiry();
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_home);
        }
        invalidateOptionsMenu(); // Refresh notification badge
    }

    private void checkBudgetExpiry() {
        String cycle = dbHelper.getBudgetCycle(userId);
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
        double totalSurplus = 0;
        int cyclesPassed = 0;

        try {
            while (true) {
                String startDateStr = dbHelper.getBudgetStartDate(userId);
                if (startDateStr == null) break;
                
                java.util.Date startDate = sdf.parse(startDateStr);
                java.util.Calendar startCal = java.util.Calendar.getInstance();
                startCal.setTime(startDate);
                java.util.Calendar today = java.util.Calendar.getInstance();

                boolean expired = false;
                java.util.Calendar nextCycleCal = (java.util.Calendar) startCal.clone();

                if (cycle.equalsIgnoreCase("Daily")) {
                    nextCycleCal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                    if (today.after(nextCycleCal) || (today.get(java.util.Calendar.DAY_OF_YEAR) != startCal.get(java.util.Calendar.DAY_OF_YEAR))) {
                        expired = true;
                    }
                } else if (cycle.equalsIgnoreCase("Weekly")) {
                    nextCycleCal.add(java.util.Calendar.WEEK_OF_YEAR, 1);
                    if (today.getTimeInMillis() >= nextCycleCal.getTimeInMillis()) {
                        expired = true;
                    }
                } else if (cycle.equalsIgnoreCase("Monthly")) {
                    nextCycleCal.add(java.util.Calendar.MONTH, 1);
                    if (today.after(nextCycleCal) || (today.get(java.util.Calendar.MONTH) != startCal.get(java.util.Calendar.MONTH))) {
                        expired = true;
                    }
                }

                if (expired) {
                    // Calculate spend for THIS specific cycle only
                    double budget = dbHelper.getUserBudget(userId);
                    String nextStartDateStr = sdf.format(nextCycleCal.getTime());
                    double total = dbHelper.getSpendInRange(userId, startDateStr, nextStartDateStr); 
                    double surplus = budget - total;
                    
                    totalSurplus += surplus;
                    cyclesPassed++;

                    // Update budget start date to the beginning of the NEXT cycle
                    dbHelper.getWritableDatabase().execSQL("UPDATE users SET savings = savings + ?, budget_start_date = ? WHERE id = ?",
                            new Object[]{surplus, nextStartDateStr, userId});
                    
                    lastNotifiedPercent = 0;
                } else {
                    break;
                }
            }

            if (cyclesPassed > 0) {
                refreshDashboard();
                String message = String.format("Budget Rollover: %d %s cycles have passed.\nTotal Savings Impact: KSh %.2f", 
                        cyclesPassed, cycle, totalSurplus);
                
                new AlertDialog.Builder(this)
                        .setTitle("System Catch-up")
                        .setMessage(message)
                        .setPositiveButton("View Dashboard", null)
                        .show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void refreshDashboard() {
        double total = dbHelper.getTotalSpend(userId);
        double budget = dbHelper.getUserBudget(userId);
        double remaining = budget - total;

        tvTotalSpend.setText(String.format("KSh %.2f", remaining));

        int percent = budget > 0 ? (int) ((total / budget) * 100) : 0;
        budgetProgressBar.setProgress(Math.min(percent, 100));
        
        if (percent >= 100) {
            budgetProgressBar.setIndicatorColor(Color.RED);
        } else {
            budgetProgressBar.setIndicatorColor(getResources().getColor(R.color.tertiary, getTheme()));
        }
        
        tvBudgetSubtitle.setText(String.format("%d%% of KSh %.2f Budget Spent", percent, budget));

        // Update Priorities
        updatePriorityUI("HIGH", tvHighSpend, tvHighPct, progressHigh);
        updatePriorityUI("MEDIUM", tvMedSpend, tvMedPct, progressMed);
        updatePriorityUI("LOW", tvLowSpend, tvLowPct, progressLow);

        tvAnalysis.setText(dbHelper.getSpendingPattern(userId));
        
        // Formatted Recent Transactions
        formatRecentTransactions();

        // Global Budget Threshold Notifications
        checkBudgetThresholds(percent);
    }

    private void formatRecentTransactions() {
        String rawExpenses = dbHelper.getRecentExpenses(userId, 5);
        if (rawExpenses.equals("No recent transactions.")) {
            tvRecentTransactions.setText(rawExpenses);
            return;
        }

        SpannableStringBuilder builder = new SpannableStringBuilder();
        String[] lines = rawExpenses.split("\n\n");

        for (String transaction : lines) {
            if (transaction.trim().isEmpty()) continue;
            
            String[] parts = transaction.split("\n");
            if (parts.length >= 2) {
                String mainInfo = parts[0]; // Title | Amount
                String dateInfo = parts[1]; // Date at Time
                
                int start = builder.length();
                builder.append(mainInfo).append("\n");
                builder.setSpan(new AbsoluteSizeSpan(17, true), start, start + mainInfo.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                builder.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), start, start + mainInfo.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                
                int dateStart = builder.length();
                builder.append(dateInfo).append("\n\n");
                builder.setSpan(new AbsoluteSizeSpan(13, true), dateStart, dateStart + dateInfo.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.on_surface_variant, getTheme())), dateStart, dateStart + dateInfo.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        tvRecentTransactions.setText(builder);
    }

    private void updatePriorityUI(String priority, TextView tvSpend, TextView tvPct, com.google.android.material.progressindicator.LinearProgressIndicator progress) {
        double spent = dbHelper.getPrioritySpend(userId, priority);
        double budget = dbHelper.getUserBudget(userId);
        int targetPct = 0;
        if (priority.equals("HIGH")) targetPct = dbHelper.getTargetHighPct(userId);
        else if (priority.equals("MEDIUM")) targetPct = dbHelper.getTargetMedPct(userId);
        else if (priority.equals("LOW")) targetPct = dbHelper.getTargetLowPct(userId);

        double priorityBudget = (targetPct / 100.0) * budget;
        int spentPct = priorityBudget > 0 ? (int) ((spent / priorityBudget) * 100) : 0;

        tvSpend.setText(String.format("KSh %.2f spent", spent));
        tvPct.setText(spentPct + "% USED" + (spentPct >= 100 ? " ❗" : ""));
        progress.setProgress(Math.min(spentPct, 100));
    }

    private void checkBudgetThresholds(int currentPercent) {
        if (currentPercent >= 100 && lastNotifiedPercent < 100) {
            String title = "Budget Depleted!";
            if (!dbHelper.hasNotification(userId, title)) {
                String message = "You have spent 100% of your total budget. Time to slow down!";
                triggerNotification(title, message);
                dbHelper.addNotification(userId, title, message);
            }
            lastNotifiedPercent = 100;
        } else if (currentPercent >= 75 && lastNotifiedPercent < 75) {
            String title = "Budget Warning (75%)";
            if (!dbHelper.hasNotification(userId, title)) {
                String message = "You have spent 75% of your total budget.";
                triggerNotification(title, message);
                dbHelper.addNotification(userId, title, message);
            }
            lastNotifiedPercent = 75;
        } else if (currentPercent >= 50 && lastNotifiedPercent < 50) {
            String title = "Budget Milestone (50%)";
            if (!dbHelper.hasNotification(userId, title)) {
                String message = "You have spent half of your total budget.";
                triggerNotification(title, message);
                dbHelper.addNotification(userId, title, message);
            }
            lastNotifiedPercent = 50;
        }
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        
        MenuItem notificationItem = menu.findItem(R.id.action_notifications);
        if (notificationItem != null) {
            int unreadCount = dbHelper.getUnreadNotificationsCount(userId);
            Toolbar toolbar = findViewById(R.id.toolbar);

            // Always detach first to ensure clean state
            com.google.android.material.badge.BadgeUtils.detachBadgeDrawable(null, toolbar, R.id.action_notifications);

            if (unreadCount > 0) {
                com.google.android.material.badge.BadgeDrawable badge = com.google.android.material.badge.BadgeDrawable.create(this);
                badge.setNumber(unreadCount);
                badge.setBackgroundColor(getResources().getColor(R.color.secondary, getTheme()));
                badge.setBadgeTextColor(Color.BLACK);
                com.google.android.material.badge.BadgeUtils.attachBadgeDrawable(badge, toolbar, R.id.action_notifications);
            }
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            Intent intent = new Intent(this, SearchHistoryActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_notifications) {
            Intent intent = new Intent(this, NotificationsActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_vault) {
            Intent intent = new Intent(this, SavingsVaultActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        } else if (id == R.id.nav_search || id == R.id.nav_history) {
            Intent intent = new Intent(this, SearchHistoryActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        } else if (id == R.id.nav_clear) {
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_reset_history, null);
            AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                    .setView(dialogView)
                    .create();

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            }

            dialogView.findViewById(R.id.btnReset).setOnClickListener(v -> {
                dbHelper.clearHistory(userId);
                refreshDashboard();
                Toast.makeText(this, "History Cleared", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            dialogView.findViewById(R.id.btnCancel).setOnClickListener(v -> dialog.dismiss());

            dialog.show();
        } else if (id == R.id.nav_logout) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "CampusSpend Alerts", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                androidx.core.app.ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    private void triggerNotification(String title, String message) {
        Intent intent = new Intent(this, NotificationsActivity.class);
        intent.putExtra("USER_ID", userId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_rounded_notifications)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setColor(getResources().getColor(R.color.primary, getTheme()))
                .setAutoCancel(true);

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify((int) System.currentTimeMillis(), builder.build());
        }
    }
}

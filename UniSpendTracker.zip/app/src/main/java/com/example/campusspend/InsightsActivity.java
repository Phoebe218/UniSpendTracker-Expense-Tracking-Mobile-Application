package com.example.campusspend;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class InsightsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LineChart expenseChart;
    private PieChart categoryPieChart;
    private TextView tvDailyAvg, tvBiggestExpense, tvCheapestExpense, tvMostFrequent;
    private TextView tvBudgetTrend, tvSavingsTrend, tvFinancialScore, tvScoreLabel, tvScoreDesc;
    private int userId = -1;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insights);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Programmatically apply font to title
        Typeface interTight = ResourcesCompat.getFont(this, R.font.inter_tight_semi_bold);
        toolbar.setTitle("Spending Insights");
        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View view = toolbar.getChildAt(i);
            if (view instanceof TextView) {
                TextView textView = (TextView) view;
                textView.setTypeface(interTight);
            }
        }
        
        toolbar.setNavigationOnClickListener(v -> finish());

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_stats_tab);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                finish();
            } else if (id == R.id.nav_vault_tab) {
                Intent intent = new Intent(this, SavingsVaultActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
                finish();
            }
            return true;
        });

        expenseChart = findViewById(R.id.expenseChart);
        categoryPieChart = findViewById(R.id.categoryPieChart);
        
        tvDailyAvg = findViewById(R.id.tvDailyAvg);
        tvBiggestExpense = findViewById(R.id.tvBiggestExpense);
        tvCheapestExpense = findViewById(R.id.tvCheapestExpense);
        tvMostFrequent = findViewById(R.id.tvMostFrequent);
        tvBudgetTrend = findViewById(R.id.tvBudgetTrend);
        tvSavingsTrend = findViewById(R.id.tvSavingsTrend);
        tvFinancialScore = findViewById(R.id.tvFinancialScore);
        tvScoreLabel = findViewById(R.id.tvScoreLabel);
        tvScoreDesc = findViewById(R.id.tvScoreDesc);

        try {
            updateInsights();
            updateChart();
            updatePieChart();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Some insights couldn't be loaded.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateInsights() {
        try {
            double dailyAvg = dbHelper.getDailyAverage(userId);
            String biggest = dbHelper.getBiggestExpense(userId);
            String cheapest = dbHelper.getCheapestExpense(userId);
            String mostFreq = dbHelper.getMostFrequentExpense(userId);

            int overCycles = dbHelper.getOverBudgetCyclesCount(userId);
            String cycle = dbHelper.getBudgetCycle(userId);
            double totalSavings = dbHelper.getSavings(userId);
            double lastSavings = dbHelper.getLastCycleSavings(userId);

            tvDailyAvg.setText(String.format("KSh %.2f", dailyAvg));
            tvBiggestExpense.setText(biggest);
            tvCheapestExpense.setText(cheapest);
            tvMostFrequent.setText(mostFreq);

            String cyclePlural = cycle.toLowerCase() + "s";
            if (cycle.equalsIgnoreCase("Daily")) cyclePlural = "days";

            int totalCycles = dbHelper.getTotalCyclesCount(userId);

            // Style Budget Trend
            if (totalCycles == 0) {
                tvBudgetTrend.setText("No budget history yet. Complete your first " + cycle.toLowerCase() + " cycle to see trends!");
            } else {
                String overCyclesStr = String.valueOf(overCycles);
                String budgetText = String.format("You have been over-budget for %s %s so far. Keep an eye on your high-priority spending to improve this!",
                        overCyclesStr, cyclePlural);
                SpannableStringBuilder budgetBuilder = new SpannableStringBuilder(budgetText);
                int start = budgetText.indexOf(overCyclesStr);
                int end = start + overCyclesStr.length();
                if (start != -1) {
                    budgetBuilder.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.primary, getTheme())), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    budgetBuilder.setSpan(new AbsoluteSizeSpan(24, true), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    budgetBuilder.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                tvBudgetTrend.setText(budgetBuilder);
            }

            // Style Savings Trend
            if (totalCycles == 0 && totalSavings == 0) {
                tvSavingsTrend.setText("Your savings vault is empty. Spend less than your budget to start accumulating savings!");
            } else {
                String totalSavingsStr = String.format("KSh %.2f", totalSavings);
                String lastSavingsStr = String.format("KSh %.2f", Math.abs(lastSavings));

                String savingsBase;
                if (lastSavings >= 0) {
                    savingsBase = String.format("Total Cumulative Savings\n%s\n\nLast %s, you saved %s!",
                            totalSavingsStr, cycle, lastSavingsStr);
                } else {
                    savingsBase = String.format("Total Cumulative Savings\n%s\n\nLast %s, you overspent by %s, which was deducted from your vault.",
                            totalSavingsStr, cycle, lastSavingsStr);
                }

                SpannableStringBuilder savingsBuilder = new SpannableStringBuilder(savingsBase);

                // Style Total Savings
                int s1 = savingsBase.indexOf(totalSavingsStr);
                int e1 = s1 + totalSavingsStr.length();
                if (s1 != -1) {
                    savingsBuilder.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.primary, getTheme())), s1, e1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    savingsBuilder.setSpan(new AbsoluteSizeSpan(28, true), s1, e1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    savingsBuilder.setSpan(new StyleSpan(Typeface.BOLD), s1, e1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }

                // Style Last Cycle Savings
                int s2 = savingsBase.lastIndexOf(lastSavingsStr);
                int e2 = s2 + lastSavingsStr.length();
                if (s2 != -1 && s2 != s1) {
                    int color = lastSavings >= 0 ? getResources().getColor(R.color.success, getTheme()) : getResources().getColor(R.color.error, getTheme());
                    savingsBuilder.setSpan(new ForegroundColorSpan(color), s2, e2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    savingsBuilder.setSpan(new AbsoluteSizeSpan(20, true), s2, e2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    savingsBuilder.setSpan(new StyleSpan(Typeface.BOLD), s2, e2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }

                tvSavingsTrend.setText(savingsBuilder);
            }

            updateFinancialScore();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateFinancialScore() {
        int totalCycles = dbHelper.getTotalCyclesCount(userId);
        int overCycles = dbHelper.getOverBudgetCyclesCount(userId);
        double totalSavings = dbHelper.getSavings(userId);
        double budget = dbHelper.getUserBudget(userId);
        
        double highSpend = dbHelper.getPrioritySpend(userId, "HIGH");
        double medSpend = dbHelper.getPrioritySpend(userId, "MEDIUM");
        double lowSpend = dbHelper.getPrioritySpend(userId, "LOW");
        double totalSpend = highSpend + medSpend + lowSpend;

        if (totalSpend == 0) {
            tvFinancialScore.setText("N/A");
            tvScoreLabel.setText("NEW ACCOUNT");
            tvScoreLabel.setTextColor(getResources().getColor(R.color.on_surface_variant, getTheme()));
            tvScoreDesc.setText("Log your first few expenses to calculate your financial health score!");
            return;
        }

        int score = 0;
        StringBuilder desc = new StringBuilder();

        // 1. Budget Discipline (30 points)
        if (totalCycles > 0) {
            int disciplineScore = (int) ((1.0 - (double) overCycles / totalCycles) * 30);
            score += disciplineScore;
            if (disciplineScore >= 25) desc.append("• Excellent budget discipline!\n");
            else if (disciplineScore >= 15) desc.append("• Fair budget management.\n");
            else desc.append("• Budget discipline needs work.\n");
        }

        // 2. Savings Rate (20 points)
        if (totalCycles > 0 && budget > 0) {
            double savingsRate = totalSavings / (budget * totalCycles);
            int savingsScore = (int) (Math.min(Math.max(savingsRate, 0), 0.2) * 100); // 0-20 points
            score += savingsScore;
            if (savingsScore >= 15) desc.append("• Saving a great portion of your budget.\n");
            else if (savingsScore > 0) desc.append("• Good start on savings.\n");
        }

        // 3. Priority Alignment (25 points)
        if (totalSpend > 0) {
            if (highSpend > medSpend && medSpend > lowSpend) {
                score += 25;
                desc.append("• Spending matches your priorities (High > Mid > Low).\n");
            } else if (highSpend > lowSpend) {
                score += 15;
                desc.append("• Priorities are mostly aligned.\n");
            } else {
                desc.append("• Warning: Low priority spending is too high.\n");
            }
        }

        // 4. Impulse Control (25 points)
        // Score based on "Other" category or simply low priority percentage
        if (totalSpend > 0) {
            double lowPct = lowSpend / totalSpend;
            int impulseScore = (int) ((1.0 - Math.min(lowPct, 0.5) * 2) * 25);
            score += impulseScore;
            if (impulseScore >= 20) desc.append("• Great impulse control!\n");
        }

        // Final UI updates
        score = Math.min(Math.max(score, 0), 100);
        String scoreText = score + "/100";
        SpannableStringBuilder scoreBuilder = new SpannableStringBuilder(scoreText);
        int slashIndex = scoreText.indexOf("/");
        if (slashIndex != -1) {
            scoreBuilder.setSpan(new AbsoluteSizeSpan(24, true), slashIndex, scoreText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            scoreBuilder.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.on_surface_variant, getTheme())), slashIndex, scoreText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tvFinancialScore.setText(scoreBuilder);
        
        if (score >= 80) {
            tvScoreLabel.setText("EXCELLENT");
            tvScoreLabel.setTextColor(getResources().getColor(R.color.success, getTheme()));
        } else if (score >= 60) {
            tvScoreLabel.setText("GOOD");
            tvScoreLabel.setTextColor(getResources().getColor(R.color.primary, getTheme()));
        } else if (score >= 40) {
            tvScoreLabel.setText("FAIR");
            tvScoreLabel.setTextColor(getResources().getColor(R.color.warning, getTheme()));
        } else {
            tvScoreLabel.setText("POOR");
            tvScoreLabel.setTextColor(getResources().getColor(R.color.error, getTheme()));
        }
        
        tvScoreDesc.setText(desc.toString().trim());
    }

    private void updateChart() {
        List<ILineDataSet> dataSets = new ArrayList<>();
        
        Typeface interTight = ResourcesCompat.getFont(this, R.font.inter_tight_medium);

        // 1. Collect all unique dates from all priorities first to ensure consistent X-axis indices
        java.util.TreeSet<String> dateSet = new java.util.TreeSet<>();
        collectDates(dbHelper.getExpenseTrend(userId, "HIGH"), dateSet);
        collectDates(dbHelper.getExpenseTrend(userId, "MEDIUM"), dateSet);
        collectDates(dbHelper.getExpenseTrend(userId, "LOW"), dateSet);
        
        List<String> sortedDates = new ArrayList<>(dateSet);

        // 2. Create datasets using the shared, sorted date list
        dataSets.add(createDataSet(dbHelper.getExpenseTrend(userId, "HIGH"), "High Priority", Color.parseColor("#EF4444"), sortedDates));
        dataSets.add(createDataSet(dbHelper.getExpenseTrend(userId, "MEDIUM"), "Mid Priority", Color.parseColor("#F59E0B"), sortedDates));
        dataSets.add(createDataSet(dbHelper.getExpenseTrend(userId, "LOW"), "Low Priority", Color.parseColor("#10B981"), sortedDates));

        LineData data = new LineData(dataSets);
        data.setValueTypeface(interTight);
        expenseChart.setData(data);
        expenseChart.getDescription().setEnabled(false);
        expenseChart.getLegend().setEnabled(true);
        expenseChart.getLegend().setTypeface(interTight);

        XAxis xAxis = expenseChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setTypeface(interTight);
        if (!sortedDates.isEmpty()) {
            xAxis.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    int idx = (int) value;
                    if (idx >= 0 && idx < sortedDates.size()) {
                        return sortedDates.get(idx);
                    }
                    return "";
                }
            });
            xAxis.setLabelRotationAngle(-45);
        }

        expenseChart.getAxisLeft().setTypeface(interTight);
        expenseChart.getAxisRight().setEnabled(false);
        expenseChart.animateX(1000);
        expenseChart.invalidate(); // Refresh
    }

    private void collectDates(Cursor cursor, java.util.Set<String> dateSet) {
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    dateSet.add(cursor.getString(0));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
    }

    private LineDataSet createDataSet(Cursor cursor, String label, int color, List<String> sortedDates) {
        List<Entry> entries = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String date = cursor.getString(0);
                double amount = cursor.getDouble(1);
                int index = sortedDates.indexOf(date);
                if (index != -1) {
                    entries.add(new Entry(index, (float) amount));
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Sort entries by X-value (index) to prevent the "back and forth" line bug in MPAndroidChart
        java.util.Collections.sort(entries, new java.util.Comparator<Entry>() {
            @Override
            public int compare(Entry e1, Entry e2) {
                return Float.compare(e1.getX(), e2.getX());
            }
        });

        LineDataSet set = new LineDataSet(entries, label);
        set.setColor(color);
        set.setLineWidth(2.5f);
        set.setDrawCircles(false);
        set.setDrawValues(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        return set;
    }

    private void updatePieChart() {
        List<PieEntry> entries = new ArrayList<>();
        Cursor cursor = dbHelper.getCategorySpending(userId);

        Typeface interTight = ResourcesCompat.getFont(this, R.font.inter_tight_medium);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                entries.add(new PieEntry((float) cursor.getDouble(1), cursor.getString(0)));
            } while (cursor.moveToNext());
            cursor.close();
        }

        if (entries.isEmpty()) {
            categoryPieChart.clear();
            return;
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTypeface(interTight);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(categoryPieChart));
        categoryPieChart.setData(data);
        categoryPieChart.setUsePercentValues(true);
        categoryPieChart.getDescription().setEnabled(false);
        categoryPieChart.setDrawHoleEnabled(true);
        categoryPieChart.setHoleColor(Color.WHITE);
        categoryPieChart.setCenterText("Categories");
        categoryPieChart.setCenterTextSize(14f);
        categoryPieChart.setCenterTextTypeface(interTight);
        categoryPieChart.setEntryLabelColor(Color.BLACK);
        categoryPieChart.setEntryLabelTypeface(interTight);
        categoryPieChart.getLegend().setEnabled(false);
        categoryPieChart.animateY(1000);
        categoryPieChart.invalidate();
    }
}

package com.example.campusspend;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.content.res.ColorStateList;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import com.google.android.material.chip.Chip;
import android.graphics.Typeface;
import com.google.android.material.chip.ChipGroup;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etTitle, etAmount;
    private AutoCompleteTextView spCategory, spPriority;
    private ChipGroup dynamicChipGroup;
    private int userId = -1;

    private String[] categories = {"🍔 Food & Snacks", "📚 Textbooks & Printing", "🚌 Matatu & Fare", "📱 Airtime & Bundles", "🎮 Fun & Entertainment", "📁 Other"};
    private String[] priorities = {"HIGH (Essentials)", "MEDIUM (Needs)", "LOW (Wants/Fun)"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "Session Error: User ID not found", Toast.LENGTH_SHORT).show();
        }

        etTitle = findViewById(R.id.etTitle);
        etAmount = findViewById(R.id.etAmount);
        spCategory = findViewById(R.id.spCategory);
        spPriority = findViewById(R.id.spPriority);
        dynamicChipGroup = findViewById(R.id.dynamicChipGroup);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Programmatically apply font to title
        Typeface titleTypeface = ResourcesCompat.getFont(this, R.font.inter_tight_semi_bold);
        toolbar.setTitle("Log Expense");
        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View view = toolbar.getChildAt(i);
            if (view instanceof TextView) {
                TextView textView = (TextView) view;
                textView.setTypeface(titleTypeface);
            }
        }

        toolbar.setNavigationOnClickListener(v -> finish());

        Button btnSave = findViewById(R.id.btnSave);

        // Populate AutoCompleteTextViews (Dropdowns)
        spCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categories));
        spPriority.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, priorities));

        loadCommonExpenses();

        // Pre-fill from Intent if coming from QuickLog (initial setup or other)
        prefillFromIntent();

        btnSave.setOnClickListener(v -> saveExpense());
    }

    private void loadCommonExpenses() {
        if (dbHelper == null) return;
        try {
            Cursor cursor = dbHelper.getCommonExpenses(userId);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        final String title = cursor.getString(0);
                        final String category = cursor.getString(1);
                        final String priority = cursor.getString(2);

                        Chip chip = new Chip(new android.view.ContextThemeWrapper(this, com.google.android.material.R.style.Widget_Material3_Chip_Assist));
                        chip.setText(title);
                        chip.setChipIconResource(R.drawable.ic_rounded_add);
                        chip.setChipIconTintResource(R.color.on_primary);
                        chip.setChipBackgroundColorResource(R.color.preset_card_bg);
                        chip.setTextColor(Color.WHITE);
                        chip.setChipStrokeWidth(0f);
                        
                        Typeface typeface = ResourcesCompat.getFont(this, R.font.inter_tight_medium);
                        chip.setTypeface(typeface);

                        chip.setOnClickListener(v -> {
                            etTitle.setText(title);
                            // Set category and priority robustly
                            setDropdownValue(spCategory, category);
                            setDropdownValue(spPriority, priority);
                        });
                        if (dynamicChipGroup != null) {
                            dynamicChipGroup.addView(chip);
                        }
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setDropdownValue(AutoCompleteTextView dropdown, String value) {
        if (value == null || dropdown == null || dropdown.getAdapter() == null) return;
        String valTrimmed = value.trim().toUpperCase();
        for (int i = 0; i < dropdown.getAdapter().getCount(); i++) {
            String item = dropdown.getAdapter().getItem(i).toString();
            if (item.toUpperCase().contains(valTrimmed)) {
                dropdown.setText(item, false);
                return;
            }
        }
    }

    private void prefillFromIntent() {
        String preTitle = getIntent().getStringExtra("PRE_TITLE");
        String preCategory = getIntent().getStringExtra("PRE_CATEGORY");
        String prePriority = getIntent().getStringExtra("PRE_PRIORITY");

        if (preTitle != null) etTitle.setText(preTitle);
        if (preCategory != null) setDropdownValue(spCategory, preCategory);
        if (prePriority != null) setDropdownValue(spPriority, prePriority);
    }

    private void saveExpense() {
        String title = etTitle.getText().toString().trim();
        String amountStr = etAmount.getText().toString().trim();
        String category = spCategory.getText().toString();
        String prioritySelected = spPriority.getText().toString();

        String priorityTag = "LOW";
        if (prioritySelected.startsWith("HIGH")) priorityTag = "HIGH";
        else if (prioritySelected.startsWith("MEDIUM")) priorityTag = "MEDIUM";

        if (title.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter title and amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

            Expense expense = new Expense(userId, title, amount, category, priorityTag, timestamp);
            dbHelper.addExpense(expense);

            Toast.makeText(this, "Expense Saved!", Toast.LENGTH_SHORT).show();
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
        }
    }
}

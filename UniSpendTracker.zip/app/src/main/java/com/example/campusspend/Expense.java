package com.example.campusspend;

public class Expense {
    private int id;
    private int userId;
    private String title;
    private double amount;
    private String category;
    private String priorityLevel; // "HIGH", "MEDIUM", "LOW"
    private String timestamp;

    public Expense(int userId, String title, double amount, String category, String priorityLevel, String timestamp) {
        this.userId = userId;
        this.title = title;
        this.amount = amount;
        this.category = category;
        this.priorityLevel = priorityLevel;
        this.timestamp = timestamp;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getTitle() { return title; }
    public double getAmount() { return amount; }
    public String getCategory() { return category; }
    public String getPriorityLevel() { return priorityLevel; }
    public String getTimestamp() { return timestamp; }
}

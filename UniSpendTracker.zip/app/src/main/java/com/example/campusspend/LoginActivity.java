package com.example.campusspend;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etUsername, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        seedData();
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvGoToRegister = findViewById(R.id.tvGoToRegister);

        btnLogin.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            int userId = dbHelper.loginUser(user, pass);
            if (userId != -1) {
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("USER_ID", userId);
                intent.putExtra("USERNAME", user);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid credentials! Check username/password or register.", Toast.LENGTH_LONG).show();
            }
        });

        tvGoToRegister.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void seedData() {
        int breeId = dbHelper.loginUser("Bree", "bree");
        if (breeId == -1) {
            dbHelper.registerUser("Bree", "bree", "Weekly", 3000, 50, 30, 20);
            breeId = dbHelper.loginUser("Bree", "bree");
            
            java.util.Calendar backdate = java.util.Calendar.getInstance();
            backdate.add(java.util.Calendar.WEEK_OF_YEAR, -12);
            java.text.SimpleDateFormat sdfDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
            dbHelper.getWritableDatabase().execSQL("UPDATE users SET budget_start_date = ?, savings = 0 WHERE id = ?", 
                    new Object[]{sdfDate.format(backdate.getTime()), breeId});
        } else {
            // One-time fix for existing Bree account corrupted by logic bug
            java.util.Calendar backdate = java.util.Calendar.getInstance();
            backdate.add(java.util.Calendar.WEEK_OF_YEAR, -12);
            java.text.SimpleDateFormat sdfDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
            dbHelper.getWritableDatabase().execSQL("UPDATE users SET budget_start_date = ?, savings = 0 WHERE id = ? AND savings < -1000",
                    new Object[]{sdfDate.format(backdate.getTime()), breeId});
        }

        Cursor cursor = dbHelper.getReadableDatabase().rawQuery("SELECT id FROM expenses WHERE user_id = ?", new String[]{String.valueOf(breeId)});
        if (cursor.getCount() > 0) {
            cursor.close();
            return;
        }
        cursor.close();

        java.util.Calendar cal = java.util.Calendar.getInstance();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault());
        String[] cats = {"🍔 Food & Snacks", "📚 Textbooks & Printing", "🚌 Matatu & Fare", "📱 Airtime & Bundles", "🎮 Fun & Entertainment", "📁 Other"};
        
        for (int w = 12; w >= 0; w--) {
            cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.WEEK_OF_YEAR, -w);
            double targetLimit = (w % 3 == 0) ? 3500 : 2500;
            double currentWeekSpend = 0;

            for (int d = 0; d < 7; d++) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                int numExp = (int) (Math.random() * 3) + 1;
                for (int e = 0; e < numExp; e++) {
                    if (currentWeekSpend > targetLimit + 200) break;
                    int catIdx = (int) (Math.random() * cats.length);
                    String category = cats[catIdx];
                    String priority = "MEDIUM";
                    double amt = 50 + (Math.random() * 200);
                    String title = "Misc Purchase";

                    if (category.contains("Food")) {
                        priority = "HIGH";
                        title = (amt > 150) ? "KFC Dinner" : "Campus Lunch";
                    } else if (category.contains("Matatu")) {
                        priority = "HIGH";
                        title = "Fare to Town";
                        amt = 50 + (Math.random() * 50);
                    } else if (category.contains("Fun")) {
                        priority = "LOW";
                        title = "Movie/Treat";
                        amt = 300 + (Math.random() * 400);
                    } else if (category.contains("Textbooks")) {
                        priority = "MEDIUM";
                        title = "Photocopying";
                        amt = 20 + (Math.random() * 50);
                    } else if (category.contains("Airtime")) {
                        priority = "HIGH";
                        title = "Bundles";
                        amt = 50 + (Math.random() * 50);
                    }
                    dbHelper.addExpense(new Expense(breeId, title, amt, category, priority, sdf.format(cal.getTime())));
                    currentWeekSpend += amt;
                }
            }
        }
    }
}
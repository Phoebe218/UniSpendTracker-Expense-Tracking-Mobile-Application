package com.example.campusspend;

public class AppNotification {
    private int id;
    private int userId;
    private String title;
    private String message;
    private String timestamp;
    private int isRead; // 0 for unread, 1 for read

    public AppNotification(int id, int userId, String title, String message, String timestamp, int isRead) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.timestamp = timestamp;
        this.isRead = isRead;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public String getTimestamp() { return timestamp; }
    public int getIsRead() { return isRead; }
}

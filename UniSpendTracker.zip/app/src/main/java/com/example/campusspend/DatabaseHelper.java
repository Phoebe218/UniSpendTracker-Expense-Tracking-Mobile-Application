package com.example.campusspend;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CampusSpend.db";
    private static final int DATABASE_VERSION = 5;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT, " +
                "budget_cycle TEXT, " +
                "total_budget REAL, " +
                "target_high INTEGER, " +
                "target_med INTEGER, " +
                "target_low INTEGER, " +
                "savings REAL DEFAULT 0.0, " +
                "budget_start_date TEXT)");

        db.execSQL("CREATE TABLE expenses (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "title TEXT, " +
                "amount REAL, " +
                "category TEXT, " +
                "priority TEXT, " +
                "timestamp TEXT)");

        db.execSQL("CREATE TABLE common_expenses (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "title TEXT, " +
                "category TEXT, " +
                "priority TEXT)");

        db.execSQL("CREATE TABLE notifications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "title TEXT, " +
                "message TEXT, " +
                "timestamp TEXT, " +
                "is_read INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 4) {
            db.execSQL("CREATE TABLE IF NOT EXISTS notifications (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "user_id INTEGER, " +
                    "title TEXT, " +
                    "message TEXT, " +
                    "timestamp TEXT, " +
                    "is_read INTEGER DEFAULT 0)");
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE users ADD COLUMN budget_start_date TEXT");
        }
    }

    public void saveCommonExpense(int userId, String title, String category, String priority) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("title", title);
        values.put("category", category);
        values.put("priority", priority);

        int id = -1;
        Cursor cursor = db.rawQuery("SELECT id FROM common_expenses WHERE user_id = ? AND title = ?", new String[]{String.valueOf(userId), title});
        if (cursor.moveToFirst()) {
            db.update("common_expenses", values, "id = ?", new String[]{String.valueOf(cursor.getInt(0))});
        } else {
            db.insert("common_expenses", null, values);
        }
        cursor.close();
        db.close();
    }

    public Cursor getCommonExpenses(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT title, category, priority FROM common_expenses WHERE user_id = ?", new String[]{String.valueOf(userId)});
    }

    public boolean registerUser(String username, String password, String cycle, double budget, int targetHigh, int targetMed, int targetLow) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("budget_cycle", cycle);
        values.put("total_budget", budget);
        values.put("target_high", targetHigh);
        values.put("target_med", targetMed);
        values.put("target_low", targetLow);
        values.put("savings", 0.0);
        values.put("budget_start_date", new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date()));

        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    public int loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        int id = -1;
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return id;
    }

    public boolean addExpense(Expense expense) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", expense.getUserId());
        values.put("title", expense.getTitle());
        values.put("amount", expense.getAmount());
        values.put("category", expense.getCategory());
        values.put("priority", expense.getPriorityLevel());
        values.put("timestamp", expense.getTimestamp());

        long result = db.insert("expenses", null, values);
        db.close();
        return result != -1;
    }

    public double getTotalSpend(int userId) {
        String startDate = getBudgetStartDate(userId);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(amount) FROM expenses WHERE user_id = ? AND timestamp >= ?", 
                new String[]{String.valueOf(userId), startDate + " 00:00"});
        double total = 0.0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public double getPrioritySpend(int userId, String priority) {
        String startDate = getBudgetStartDate(userId);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(amount) FROM expenses WHERE user_id = ? AND priority = ? AND timestamp >= ?", 
                new String[]{String.valueOf(userId), priority, startDate + " 00:00"});
        double total = 0.0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public double getUserBudget(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT total_budget FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        double budget = 0.0;
        if (cursor.moveToFirst()) budget = cursor.getDouble(0);
        cursor.close();
        db.close();
        return budget;
    }

    public int getTargetHighPct(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT target_high FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        int pct = 50;
        if (cursor.moveToFirst()) pct = cursor.getInt(0);
        cursor.close();
        db.close();
        return pct;
    }

    public int getTargetMedPct(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT target_med FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        int pct = 30;
        if (cursor.moveToFirst()) pct = cursor.getInt(0);
        cursor.close();
        db.close();
        return pct;
    }

    public int getTargetLowPct(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT target_low FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        int pct = 20;
        if (cursor.moveToFirst()) pct = cursor.getInt(0);
        cursor.close();
        db.close();
        return pct;
    }

    public double getSavings(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT savings FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        double savings = 0.0;
        if (cursor.moveToFirst()) savings = cursor.getDouble(0);
        cursor.close();
        db.close();
        return savings;
    }

    public void addSavings(int userId, double amount) {
        double current = getSavings(userId);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("savings", current + amount);
        db.update("users", cv, "id = ?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public String getSpendingPattern(int userId) {
        double total = getTotalSpend(userId);
        if (total == 0) return "No expenses logged yet.\nClick + New Expense below!";
        return "Keep track of your spending across priorities to maintain your financial health.";
    }

    public void addNotification(int userId, String title, String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("title", title);
        values.put("message", message);
        values.put("timestamp", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()));
        values.put("is_read", 0);
        db.insert("notifications", null, values);
        db.close();
    }

    public boolean hasNotification(int userId, String title) {
        String startDate = getBudgetStartDate(userId);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM notifications WHERE user_id = ? AND title = ? AND timestamp >= ?", 
                new String[]{String.valueOf(userId), title, startDate + " 00:00"});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public int getUnreadNotificationsCount(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", new String[]{String.valueOf(userId)});
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        db.close();
        return count;
    }

    public Cursor getNotifications(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT id, user_id, title, message, timestamp, is_read FROM notifications WHERE user_id = ? ORDER BY id DESC", new String[]{String.valueOf(userId)});
    }

    public void markNotificationsAsRead(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_read", 1);
        db.update("notifications", values, "user_id = ?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public String searchExpenses(int userId, String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title, amount, category, priority, timestamp FROM expenses WHERE user_id = ? AND (title LIKE ? OR category LIKE ? OR priority LIKE ?) ORDER BY id DESC",
                new String[]{String.valueOf(userId), "%" + query + "%", "%" + query + "%", "%" + query + "%"});

        StringBuilder sb = new StringBuilder();
        if (cursor.moveToFirst()) {
            do {
                sb.append("• ").append(cursor.getString(0))
                        .append(" - KSh ").append(String.format("%.2f", cursor.getDouble(1)))
                        .append(" [").append(cursor.getString(3)).append("]\n  ")
                        .append(cursor.getString(4)).append("\n\n");
            } while (cursor.moveToNext());
        } else {
            sb.append("No matching transactions found.");
        }
        cursor.close();
        db.close();
        return sb.toString();
    }

    public String getRecentExpenses(int userId, int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title, amount, timestamp FROM expenses WHERE user_id = ? ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(userId), String.valueOf(limit)});

        StringBuilder sb = new StringBuilder();
        
        java.text.SimpleDateFormat inputFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault());
        java.text.SimpleDateFormat outputFormat = new java.text.SimpleDateFormat("MMMM d, yyyy 'at' h:mm a", java.util.Locale.getDefault());

        if (cursor.moveToFirst()) {
            do {
                String dateStr = cursor.getString(2);
                try {
                    java.util.Date date = inputFormat.parse(dateStr);
                    if (date != null) {
                        dateStr = outputFormat.format(date);
                    }
                } catch (Exception e) {}
                
                sb.append(cursor.getString(0)).append(" — KSh ").append(String.format("%.2f", cursor.getDouble(1)))
                        .append("\n").append(dateStr).append("\n\n");
            } while (cursor.moveToNext());
        } else {
            sb.append("No recent transactions.");
        }
        cursor.close();
        db.close();
        return sb.toString();
    }

    public Cursor getExpenseTrend(int userId, String priority) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT substr(timestamp, 1, 10) as date, SUM(amount) FROM expenses " +
                        "WHERE user_id = ? AND priority = ? " +
                        "GROUP BY date ORDER BY date ASC",
                new String[]{String.valueOf(userId), priority});
    }

    public Cursor getCategorySpending(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT category, SUM(amount) FROM expenses WHERE user_id = ? GROUP BY category",
                new String[]{String.valueOf(userId)});
    }

    public void deleteNotification(int notificationId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("notifications", "id = ?", new String[]{String.valueOf(notificationId)});
        db.close();
    }

    public void clearHistory(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM expenses WHERE user_id = ?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public String getBudgetCycle(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT budget_cycle FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        String cycle = "Monthly";
        if (cursor.moveToFirst()) cycle = cursor.getString(0);
        cursor.close();
        db.close();
        return cycle;
    }

    public String getBudgetStartDate(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT budget_start_date FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        String date = null;
        if (cursor.moveToFirst()) date = cursor.getString(0);
        cursor.close();
        db.close();
        return date;
    }

    public void rolloverBudget(int userId, double surplus) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT savings FROM users WHERE id = ?", new String[]{String.valueOf(userId)});
        double currentSavings = 0;
        if (cursor.moveToFirst()) currentSavings = cursor.getDouble(0);
        cursor.close();

        ContentValues values = new ContentValues();
        values.put("savings", currentSavings + surplus);
        values.put("budget_start_date", new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date()));
        
        db.update("users", values, "id = ?", new String[]{String.valueOf(userId)});
        // Do not delete expenses to preserve history for viewing
        db.close();
    }

    public void updateBudget(int userId, double newBudget, String newCycle) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("total_budget", newBudget);
        cv.put("budget_cycle", newCycle);
        cv.put("budget_start_date", new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date()));
        db.update("users", cv, "id = ?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public double getDailyAverage(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(amount), COUNT(DISTINCT substr(timestamp, 1, 10)) FROM expenses WHERE user_id = ?", new String[]{String.valueOf(userId)});
        double avg = 0.0;
        if (cursor.moveToFirst()) {
            double total = cursor.getDouble(0);
            int days = cursor.getInt(1);
            if (days > 0) avg = total / days;
        }
        cursor.close();
        return avg;
    }

    public String getBiggestExpense(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title, amount FROM expenses WHERE user_id = ? ORDER BY amount DESC LIMIT 1", new String[]{String.valueOf(userId)});
        String result = "N/A";
        if (cursor.moveToFirst()) {
            result = cursor.getString(0) + " (KSh " + String.format("%.2f", cursor.getDouble(1)) + ")";
        }
        cursor.close();
        return result;
    }

    public String getCheapestExpense(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title, amount FROM expenses WHERE user_id = ? ORDER BY amount ASC LIMIT 1", new String[]{String.valueOf(userId)});
        String result = "N/A";
        if (cursor.moveToFirst()) {
            result = cursor.getString(0) + " (KSh " + String.format("%.2f", cursor.getDouble(1)) + ")";
        }
        cursor.close();
        return result;
    }

    public String getMostFrequentExpense(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title, COUNT(*) as freq FROM expenses WHERE user_id = ? GROUP BY title ORDER BY freq DESC LIMIT 1", new String[]{String.valueOf(userId)});
        String result = "N/A";
        if (cursor.moveToFirst()) {
            result = cursor.getString(0) + " (" + cursor.getInt(1) + " times)";
        }
        cursor.close();
        return result;
    }

    public int getOverBudgetCyclesCount(int userId) {
        double budget = getUserBudget(userId);
        String cycle = getBudgetCycle(userId);
        
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor firstCursor = db.rawQuery("SELECT MIN(timestamp) FROM expenses WHERE user_id = ?", new String[]{String.valueOf(userId)});
        String firstDateStr = null;
        if (firstCursor.moveToFirst()) firstDateStr = firstCursor.getString(0);
        firstCursor.close();
        
        if (firstDateStr == null || firstDateStr.length() < 10) return 0;
        
        int overCount = 0;
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(sdf.parse(firstDateStr.substring(0, 10)));
            java.util.Calendar today = java.util.Calendar.getInstance();
            
            while (cal.before(today)) {
                java.util.Calendar startOfCycle = (java.util.Calendar) cal.clone();
                if (cycle.equalsIgnoreCase("Daily")) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                else if (cycle.equalsIgnoreCase("Weekly")) cal.add(java.util.Calendar.WEEK_OF_YEAR, 1);
                else if (cycle.equalsIgnoreCase("Monthly")) cal.add(java.util.Calendar.MONTH, 1);
                else cal.add(java.util.Calendar.DAY_OF_YEAR, 1); // Default to prevent infinite loop
                
                if (cal.before(today) || cal.equals(today)) {
                    double spend = getSpendInRange(userId, sdf.format(startOfCycle.getTime()), sdf.format(cal.getTime()));
                    if (spend > budget) overCount++;
                } else {
                    break;
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return overCount;
    }

    public int getTotalCyclesCount(int userId) {
        String cycle = getBudgetCycle(userId);
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor firstCursor = db.rawQuery("SELECT MIN(timestamp) FROM expenses WHERE user_id = ?", new String[]{String.valueOf(userId)});
        String firstDateStr = null;
        if (firstCursor.moveToFirst()) firstDateStr = firstCursor.getString(0);
        firstCursor.close();

        if (firstDateStr == null || firstDateStr.length() < 10) return 0;

        int totalCount = 0;
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(sdf.parse(firstDateStr.substring(0, 10)));
            java.util.Calendar today = java.util.Calendar.getInstance();

            while (cal.before(today)) {
                if (cycle.equalsIgnoreCase("Daily")) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                else if (cycle.equalsIgnoreCase("Weekly")) cal.add(java.util.Calendar.WEEK_OF_YEAR, 1);
                else if (cycle.equalsIgnoreCase("Monthly")) cal.add(java.util.Calendar.MONTH, 1);
                else cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                totalCount++;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return totalCount;
    }

    public double getSpendInRange(int userId, String start, String end) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(amount) FROM expenses WHERE user_id = ? AND timestamp >= ? AND timestamp < ?", 
                new String[]{String.valueOf(userId), start + " 00:00", end + " 00:00"});
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        return total;
    }

    public double getLastCycleSavings(int userId) {
        double budget = getUserBudget(userId);
        String cycle = getBudgetCycle(userId);
        String startDateStr = getBudgetStartDate(userId);
        if (startDateStr == null) return 0;
        
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(sdf.parse(startDateStr));
            
            java.util.Calendar endOfLast = (java.util.Calendar) cal.clone();
            if (cycle.equalsIgnoreCase("Daily")) cal.add(java.util.Calendar.DAY_OF_YEAR, -1);
            else if (cycle.equalsIgnoreCase("Weekly")) cal.add(java.util.Calendar.WEEK_OF_YEAR, -1);
            else if (cycle.equalsIgnoreCase("Monthly")) cal.add(java.util.Calendar.MONTH, -1);
            else cal.add(java.util.Calendar.DAY_OF_YEAR, -1);
            
            double spend = getSpendInRange(userId, sdf.format(cal.getTime()), sdf.format(endOfLast.getTime()));
            return budget - spend;
        } catch (Exception e) { return 0; }
    }
}

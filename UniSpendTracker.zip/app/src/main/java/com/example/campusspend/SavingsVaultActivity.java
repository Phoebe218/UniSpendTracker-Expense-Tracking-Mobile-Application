package com.example.campusspend;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SavingsVaultActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView tvVaultBalance;
    private EditText etDeposit;
    private int userId = -1;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savings_vault);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Programmatically apply font to title
        Typeface titleTypeface = ResourcesCompat.getFont(this, R.font.inter_tight_semi_bold);
        toolbar.setTitle("Savings Vault");
        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View view = toolbar.getChildAt(i);
            if (view instanceof TextView) {
                TextView textView = (TextView) view;
                textView.setTypeface(titleTypeface);
            }
        }
        
        toolbar.setNavigationOnClickListener(v -> finish());

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_vault_tab);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                finish(); // Go back to MainActivity
            } else if (id == R.id.nav_stats_tab) {
                Intent intent = new Intent(this, InsightsActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
                finish();
            }
            return true;
        });

        tvVaultBalance = findViewById(R.id.tvVaultBalance);
        etDeposit = findViewById(R.id.etDeposit);
        Button btnDeposit = findViewById(R.id.btnDeposit);

        refreshVault();

        btnDeposit.setOnClickListener(v -> {
            String depStr = etDeposit.getText().toString().trim();
            if (depStr.isEmpty()) {
                Toast.makeText(this, "Enter an amount", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double amt = Double.parseDouble(depStr);
                dbHelper.addSavings(userId, amt);
                etDeposit.setText("");
                refreshVault();
                Toast.makeText(this, "🎉 Awesome! KSh " + amt + " saved to your Vault!", Toast.LENGTH_LONG).show();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshVault() {
        double current = dbHelper.getSavings(userId);
        tvVaultBalance.setText(String.format("KSh %.2f", current));
    }
}

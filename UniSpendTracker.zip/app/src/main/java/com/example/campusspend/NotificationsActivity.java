package com.example.campusspend;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int userId = -1;
    private RecyclerView rvNotifications;
    private View emptyState;
    private NotificationAdapter adapter;
    private List<AppNotification> notificationList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        rvNotifications = findViewById(R.id.rvNotifications);
        emptyState = findViewById(R.id.emptyState);
        
        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NotificationAdapter(notificationList, notificationId -> {
            dbHelper.deleteNotification(notificationId);
            loadNotifications();
        });
        rvNotifications.setAdapter(adapter);

        // Mark all as read when screen is opened
        if (userId != -1) {
            dbHelper.markNotificationsAsRead(userId);
        }

        loadNotifications();
    }

    private void loadNotifications() {
        notificationList.clear();
        Cursor cursor = dbHelper.getNotifications(userId);
        
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    notificationList.add(new AppNotification(
                        cursor.getInt(0), // ID
                        cursor.getInt(1), // UserId
                        cursor.getString(2), // Title
                        cursor.getString(3), // Message
                        cursor.getString(4), // Time
                        cursor.getInt(5)    // isRead
                    ));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        if (notificationList.isEmpty()) {
            emptyState.setVisibility(View.VISIBLE);
            rvNotifications.setVisibility(View.GONE);
        } else {
            emptyState.setVisibility(View.GONE);
            rvNotifications.setVisibility(View.VISIBLE);
            adapter.notifyDataSetChanged();
        }
    }
}

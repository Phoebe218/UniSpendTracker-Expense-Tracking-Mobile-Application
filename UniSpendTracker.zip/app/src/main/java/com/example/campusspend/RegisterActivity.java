package com.example.campusspend;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etUser, etPass, etBudget, etHigh, etMed, etLow;
    private AutoCompleteTextView spCycle;

    private String[] cycles = {"Daily Upkeep", "Weekly Upkeep", "Monthly Upkeep"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);

        etUser = findViewById(R.id.etRegUser);
        etPass = findViewById(R.id.etRegPass);
        etBudget = findViewById(R.id.etBudget);
        etHigh = findViewById(R.id.etHighTarget);
        etMed = findViewById(R.id.etMedTarget);
        etLow = findViewById(R.id.etLowTarget);
        spCycle = findViewById(R.id.spCycle);
        Button btnRegister = findViewById(R.id.btnRegister);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cycles);
        spCycle.setAdapter(adapter);

        btnRegister.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            String bStr = etBudget.getText().toString().trim();
            String hStr = etHigh.getText().toString().trim();
            String mStr = etMed.getText().toString().trim();
            String lStr = etLow.getText().toString().trim();
            String selectedCycle = spCycle.getText().toString();

            if (u.isEmpty() || p.isEmpty() || bStr.isEmpty() || hStr.isEmpty() || mStr.isEmpty() || lStr.isEmpty() || selectedCycle.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double budget = Double.parseDouble(bStr);
                int h = Integer.parseInt(hStr);
                int m = Integer.parseInt(mStr);
                int l = Integer.parseInt(lStr);

                if ((h + m + l) != 100) {
                    Toast.makeText(this, "Target percentages must sum up to exactly 100%!", Toast.LENGTH_LONG).show();
                    return;
                }

                boolean success = dbHelper.registerUser(u, p, selectedCycle, budget, h, m, l);
                if (success) {
                    int userId = dbHelper.loginUser(u, p);
                    if (userId != -1) {
                        Intent intent = new Intent(RegisterActivity.this, QuickLogActivity.class);
                        intent.putExtra("USER_ID", userId);
                        intent.putExtra("USERNAME", u);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        Toast.makeText(this, "Welcome, " + u + "!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Account Created! Please Sign In.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                } else {
                    Toast.makeText(this, "Registration failed or username exists. Try another username.", Toast.LENGTH_LONG).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid numbers entered", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

package com.example.campusspend;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Button btnGetStarted = findViewById(R.id.btnGetStarted);
        Button btnExistingUser = findViewById(R.id.btnExistingUser);

        btnGetStarted.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        btnExistingUser.setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));
    }
}
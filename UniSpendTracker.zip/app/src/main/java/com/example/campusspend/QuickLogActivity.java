package com.example.campusspend;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.HashMap;
import java.util.Map;

public class QuickLogActivity extends AppCompatActivity {

    private int userId;
    private String username;
    private ChipGroup groupPool, groupHigh, groupMedium, groupLow;
    private CardView cardHigh, cardMedium, cardLow;

    private final String[] commonExpenses = {
            "Transport", "Breakfast", "Lunch", "Supper", "Snacks",
            "Stationery", "Fuel", "Netflix", "Spotify",
            "Groceries", "Toiletries", "Haircut", "Clothes", "Airtime"
    };

    private final Map<String, String> categoryMap = new HashMap<>() {{
        put("Transport", "Matatu & Fare");
        put("Breakfast", "Food & Snacks");
        put("Lunch", "Food & Snacks");
        put("Supper", "Food & Snacks");
        put("Snacks", "Food & Snacks");
        put("Stationery", "Textbooks & Printing");
        put("Fuel", "Matatu & Fare");
        put("Netflix", "Fun & Entertainment");
        put("Spotify", "Fun & Entertainment");
        put("Groceries", "Food & Snacks");
        put("Toiletries", "Food & Snacks");
        put("Haircut", "Fun & Entertainment");
        put("Clothes", "Fun & Entertainment");
        put("Airtime", "Airtime & Bundles");
    }};

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_log);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);
        username = getIntent().getStringExtra("USERNAME");

        groupPool = findViewById(R.id.groupPool);
        groupHigh = findViewById(R.id.groupHigh);
        groupMedium = findViewById(R.id.groupMedium);
        groupLow = findViewById(R.id.groupLow);

        cardHigh = findViewById(R.id.cardHigh);
        cardMedium = findViewById(R.id.cardMedium);
        cardLow = findViewById(R.id.cardLow);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            Typeface titleTypeface = ResourcesCompat.getFont(this, R.font.inter_tight_semi_bold);
            for (int i = 0; i < toolbar.getChildCount(); i++) {
                View view = toolbar.getChildAt(i);
                if (view instanceof TextView) {
                    TextView textView = (TextView) view;
                    textView.setTypeface(titleTypeface);
                }
            }
        }

        Button btnDashboard = findViewById(R.id.btnDashboard);

        setupDragTargets();
        populatePool();

        btnDashboard.setOnClickListener(v -> {
            saveAllMappings();
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("USER_ID", userId);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
            finish();
        });
    }

    private void saveAllMappings() {
        saveFromGroup(groupHigh, "HIGH");
        saveFromGroup(groupMedium, "MEDIUM");
        saveFromGroup(groupLow, "LOW");
    }

    private void saveFromGroup(ChipGroup group, String priority) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View v = group.getChildAt(i);
            if (v instanceof Chip) {
                String title = ((Chip) v).getText().toString();
                String category = categoryMap.getOrDefault(title, "Other");
                dbHelper.saveCommonExpense(userId, title, category, priority);
            }
        }
    }

    private void populatePool() {
        // Load existing mappings
        Map<String, String> existingMappings = new HashMap<>();
        Cursor cursor = dbHelper.getCommonExpenses(userId);
        if (cursor.moveToFirst()) {
            do {
                existingMappings.put(cursor.getString(0), cursor.getString(2));
            } while (cursor.moveToNext());
        }
        cursor.close();

        for (String item : commonExpenses) {
            Chip chip = createChip(item);
            String assignedPriority = existingMappings.get(item);

            if (assignedPriority == null) {
                groupPool.addView(chip);
            } else {
                switch (assignedPriority) {
                    case "HIGH": groupHigh.addView(chip); break;
                    case "MEDIUM": groupMedium.addView(chip); break;
                    case "LOW": groupLow.addView(chip); break;
                    default: groupPool.addView(chip); break;
                }
            }
        }
    }

    private Chip createChip(String text) {
        Chip chip = new Chip(new android.view.ContextThemeWrapper(this, com.google.android.material.R.style.Widget_Material3_Chip_Assist));
        chip.setText(text);
        chip.setCheckable(false);
        chip.setClickable(true);
        chip.setChipBackgroundColorResource(R.color.preset_card_bg);
        chip.setTextColor(Color.WHITE);
        chip.setChipStrokeWidth(0f);
        
        Typeface typeface = ResourcesCompat.getFont(this, R.font.inter_tight_medium);
        chip.setTypeface(typeface);

        chip.setOnLongClickListener(v -> {
            ClipData.Item clipItem = new ClipData.Item(text);
            ClipData dragData = new ClipData(text, new String[]{ClipDescription.MIMETYPE_TEXT_PLAIN}, clipItem);
            View.DragShadowBuilder myShadow = new View.DragShadowBuilder(chip);
            v.startDragAndDrop(dragData, myShadow, v, 0);
            return true;
        });

        chip.setOnClickListener(v -> Toast.makeText(this, "Long-press to drag to a priority bucket", Toast.LENGTH_SHORT).show());
        return chip;
    }

    private void setupDragTargets() {
        cardHigh.setOnDragListener(new MyDragListener("HIGH", groupHigh));
        cardMedium.setOnDragListener(new MyDragListener("MEDIUM", groupMedium));
        cardLow.setOnDragListener(new MyDragListener("LOW", groupLow));
    }

    private class MyDragListener implements View.OnDragListener {
        private final String priority;
        private final ChipGroup targetGroup;

        public MyDragListener(String priority, ChipGroup targetGroup) {
            this.priority = priority;
            this.targetGroup = targetGroup;
        }

        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return event.getClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN);

                case DragEvent.ACTION_DRAG_ENTERED:
                    v.setAlpha(0.5f);
                    return true;

                case DragEvent.ACTION_DRAG_EXITED:
                case DragEvent.ACTION_DRAG_ENDED:
                    v.setAlpha(1.0f);
                    return true;

                case DragEvent.ACTION_DROP:
                    View draggedView = (View) event.getLocalState();
                    if (draggedView != null) {
                        ChipGroup parent = (ChipGroup) draggedView.getParent();
                        if (parent != null) {
                            parent.removeView(draggedView);
                            targetGroup.addView(draggedView);
                        }
                    }
                    return true;

                default:
                    break;
            }
            return false;
        }
    }
}
